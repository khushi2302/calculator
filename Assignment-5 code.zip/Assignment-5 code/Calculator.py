import math
class Calculator: 
  def add(self, a, b):
    return a+b
  def subtract(self, a, b):
    return a-b
  def squareRoot(self, a):
    return math.sqrt(a)
  def multiply(self,a, b):
    return a*b